%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% EXTRACTENERGYPROFILE.m: 
% Extract the energy profile of the protein backbone chain during its 
% folding process. 
%
% MATLAB M-File associated with the article: "Wave Space Sonification of 
% Folding Pathways of Protein Molecules Modeled as Hyper-Redundant Robotic
% Mechanisms", Multimedia Tools and Applications (Springer Nature)
%
% Note: Contact the corresponding author Dr. Alireza Mohammadi
% (amohmmad@umich.edu) for any further assistance/information. 
%
% This version: 02-12-2023
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
clear; close all; 
%
% Extract the energy profile of the protein molecule from fig6.fig. 
fig = open('fig6.fig'); 
set(gcf, 'Position', get(0, 'Screensize'));
%
set(gca,'FontSize',40)
%
ax = gca; 
h = findobj(gca,'Type','line');
%
xIteration = h.XData; 
yEnergy = h.YData;
%
plot(xIteration, yEnergy, 'k', 'LineWidth', 3)
%
% Protein molecule conformations during folding
%fig1 = open('fig1.fig'); 
%fig2 = open('fig2.fig'); 
%fig3 = open('fig3.fig'); 
%fig4 = open('fig4.fig'); 
%fig5 = open('fig5.fig'); 
%
% Uncomment to print  the   generated figures  to  files. 
% print(fig,'energyFolding','-dpng','-r400')
% print(fig1,'folding1','-dpng','-r400')
% print(fig2,'folding2','-dpng','-r400')
% print(fig3,'folding3','-dpng','-r400')
% print(fig4,'folding4','-dpng','-r400')
% print(fig5,'folding5','-dpng','-r400')
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~






