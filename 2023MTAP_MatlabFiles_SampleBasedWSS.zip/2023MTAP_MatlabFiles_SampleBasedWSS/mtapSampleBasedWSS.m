%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% MTAPSAMPLEBASEDWSS.m: 
% Sample-Based WSS M-File for sonification of the folding trajectories 
% of the backbone chain of the example protein molecule using 
% Mozart's Alla Turca
%
% MATLAB M-File associated with the article: "Wave Space Sonification of 
% Folding Pathways of Protein Molecules Modeled as Hyper-Redundant Robotic
% Mechanisms" Multimedia Tools and Applications (Springer Nature)
%
% Note: Contact the corresponding author Dr. Alireza Mohammadi
% (amohmmad@umich.edu) for any further assistance/information. 
%
%
% This version: 02-11-2023
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
clear;  close all; 
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-0: Set the figure/sound file names for writing the final results to.  
figStr1  = 'sampleBasedcFun';
figStr2  = 'sampleBasedst';
figStr3  = 'sampleBasedSpectro';
audioStr = 'mozartSampleBased';
%  
% Choose flagNum to be an integer between 1 and 4. 
flagNum = 1;  %1->sigma0=0.25; 2->sigma0=0.5; 3->sigma0=0.75; 4->sigma0=1
figStr1 = [figStr1,num2str(flagNum)];
figStr2 = [figStr2,num2str(flagNum)];
figStr3 = [figStr3,num2str(flagNum)];
audioStr = [audioStr,num2str(flagNum),'.wav'];
fileStr = 'simulResult'; 
fileStr2 = {'1.mat','2.mat','3.mat','4.mat','5.mat','6.mat'};
%
fileStr = [fileStr,fileStr2{flagNum}];
% Set the sample based sonification parameters. 
lambda0= 1;
sigma0Mat = [0.25; 0.5; 0.75; 1]; 
sigma0 = sigma0Mat(flagNum);
flagInnerPlot = 1; 
%
disp(' ')
disp('Your chosen sigma0 parameter for the scaling function:')
disp(' ')
disp(sigma0Mat(flagNum))
disp('Sonification in  process. Please wait  ... ')
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-1: Create a spline object from the folding pathway trajectory 
% provided in the data file "sonificationData.mat"
%
load("sonificationData.mat");
Nfolding = length(  thVec(1,:) ); 
thVecSpline = spline(linspace(0,1,Nfolding),thVec ); 
%
% Compute the nonlinear scaling function for later use in sample-based WSS
% sonification. 
cscale = zeros(1,Nfolding); 
% 
mu_unf = thVec(:,1);   % Unfolded protein conformation 
mu_fol = thVec(:,end); % Folded protein conformation 
%
% Set the denominator of the nonlinear scaling function. 
denominator = (sigma0^2)    *   (  norm(mu_unf - mu_fol)   );
%
% Compute the samples of the nonlinear scaling function  
for ii = 1 : Nfolding
    cscale(ii) = lambda0 * exp(    -( ...
        norm( thVec(:,ii)-mu_fol )/ denominator ) );
    %
    if ~sigma0 % Use sigma0 = 0 for playing the base sound file (i.e., 
               % Mozart's Alla Turca in this example)
         cscale(ii) = (ii-1)/Nfolding; 
    end
end
%
% Create a spline object from the nonlinear scaling function for sampling 
% from Mozart's Alla Turca. 
%
cscale = ( cscale  - min(cscale) ) / max(cscale); 
cscale = cscale/max(cscale); 
cscaleSpline = spline( linspace(0,1,Nfolding), cscale); 
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-2: Pre-process the original sound file 'moz.wav'. 
NumLow = 3;  % NumLow = 1 ---> sound with original quality
Fs0 = 44000; % Base music playback frequency
%
yMozart = audioread('moz.wav')'; 
NMozartMusic = length(yMozart);       % NMozartMusic
yMozart = yMozart(:,1:NMozartMusic);  
%
% Sample the original sound file for a faster computation. 
yMozart = yMozart(1:NumLow:NMozartMusic); 
% Create a spline object from the sampled sound file.  
mozSpline   = spline(linspace(0,1, length(yMozart)) , yMozart) ;
%
% Set the frequency for playback of the protein folding pathway sonified 
% dataset on the PC speakers
%
Fs  = floor(Fs0 / NumLow) ; 
Nmozart = length(yMozart);
Tmozart = Nmozart / Fs;
%
% Uncomment to hear the original piece of music. 
% sound(yMozart,Fs);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-3: Use the sample-based WSS function to sonify the folding pathway 
% of the protein molecule. 
%
% Pre-assign the variable for accelerating the loop computations. 
yMozartWSS = zeros(1,Nmozart);
%
% The main computational loop for the generation of the WSS-based sound
% from the protein folding pathway. 
%
for ii = 1 : Nmozart
    tii = (ii-1)/Nmozart; 
    yMozartWSS(ii) = ppval(mozSpline , ppval(cscaleSpline,tii));
end
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-4: Draw the final results and generate the WSS-based sound. Save the 
% generated data in files defined in Step-0. 
%
fig1 = figure('units','normalized','outerposition',[0 0 1 1]);
plot(linspace(0,Tmozart,length(yMozartWSS)),yMozartWSS,'k',...
    'linewidth',0.01)
hold on 
grid on
xlabel('$$t$$ [s]','interpreter','latex','fontSize',30)
ylabel('$$s(t)$$','interpreter',...
    'latex','fontSize',30)
set(gca,'FontSize',30)
if ~flagInnerPlot
    ylabel('$$s_{\mathcal{M}}(t)$$','interpreter',...
    'latex','fontSize',40) 
else 
    axes('Position',[.16 .72 .2 .2])
    box on
    plot(linspace(0,Tmozart,Nfolding), cscale,'k','LineWidth',2)
    hold on 
    grid on
    ylabel('$$c_0($${\boldmath$\theta$}$$(M(t)))$$','interpreter',...
        'latex','fontSize',25)
    xlabel('$$t$$','interpreter',...
        'latex','fontSize',25)
    set(gca,'YTickLabel',[]);
    set(gca,'XTickLabel',[]);
    %
end
%
% Uncomment  to print  the  figure to a png file. 
% print(fig1,figStr2,'-dpng','-r150')
% clear fig1
%
fig2 = figure('units','normalized','outerposition',[0 0 1 1]);
pspectrum(yMozartWSS,linspace(0,Tmozart,...
    length(yMozartWSS)),'spectrogram')
%
title('')
xlabel('$$t$$ [s]','interpreter','latex','fontSize',40)
ylabel('$$f$$ [kHz]','interpreter',...
    'latex','fontSize',40)
set(gca,'FontSize',40)
%
% Uncomment  to print  the  figure to a png file. 
% print(fig2,figStr3,'-dpng','-r150')
% clear fig2
%
sound(yMozartWSS,Fs);
% Uncomment to  write the generated sound to a .wav file. 
% audiowrite(audioStr,yMozartWSS,Fs)
%
% Uncomment  to save the  results in a .mat file. 
% save(fileStr)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
