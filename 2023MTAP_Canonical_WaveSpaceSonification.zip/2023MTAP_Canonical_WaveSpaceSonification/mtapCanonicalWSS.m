%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% MTAPCANONICALWSS.m: 
% Canonical WSS M-File for sonification of the folding trajectories 
% of the backbone chain of the example protein molecule using 
% sinusoidal functions
%
% MATLAB M-File associated with the article: "Wave Space Sonification of 
% Folding Pathways of Protein Molecules Modeled as Hyper-Redundant Robotic
% Mechanisms" Multimedia Tools and Applications (Springer Nature)
%
% Note: Contact the corresponding author Dr. Alireza Mohammadi
% (amohmmad@umich.edu) for any further assistance/information. 
%
%
% This version: 02-11-2023
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
clear; close all; clc;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-0: Set the figure/sound file names for writing the final results to.  
%
% Choose flagNum to be an integer between 1 and 5. 
flagNum = 1;  %1->sigma0=0.1; 2->sigma0=0.15; 3->sigma0=0.2; 4->sigma0=0.3;
              %5->sigma0=0.4;
%
figStr2 = 'canonicalSt';
figStr3 = 'canonicalSpectro';
%
figStr2 = [figStr2,num2str(flagNum)];
figStr3 = [figStr3,num2str(flagNum)];
fileStr = 'simulResult'; 
fileStr2 = {'1.mat','2.mat','3.mat','4.mat','5.mat'};
audioStr = 'canonicalWSS';
audioStr = [audioStr,num2str(flagNum),'.wav'];
%
fileStr = [fileStr,fileStr2{flagNum}];
sigma0Mat = [0.1; 0.15; 0.2; 0.3; 0.4]; 
%
disp(' ')
disp('Your chosen sigma0 parameter for the frequency scaling function:')
disp(' ')
disp(sigma0Mat(flagNum))
disp('Sonification in  process. Please wait  ... ')
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-1: Load the folding pathway trajectory dataset 
% provided in the data file "sonificationData.mat". 
%
% Load the protein folding pathway dataset. 
load("sonificationData.mat");
thVec = thVec(2:end-1,:);
% Extract the information about the folded and unfoled conformations
xStart = thVec(:,1); 
xFinish = thVec(:,end);
mu_unf = xStart ; % The unfolded protein conformation 
mu_fol = xFinish; % The folded protein conformation 
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-2: Load the folding pathway trajectory dataset provided in the 
% data file "sonificationData.mat". 
%
% The design parameters that are chosen by the use
Fs = 6000; %Sampling frequency
F0 = 250;  %Fundamental frequency
sigma0 = sigma0Mat(flagNum); 
%
% Set the duration of the desired canonical WSS-based sound file
duration = 5;  % in seconds  
% Set  L, i.e., the length of the generated WSS-based sound vector 
L = Fs*duration; 
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-3: The main computations for generating the canonical WSS-based
% sound file. 
%
% The linear interpolation function. 
Nsmax = length(thVec(1,:));
Ns = (Nsmax-1)/(L-1);   
%
N = 1:Nsmax;
NN = 1:Ns:Nsmax;
%
fi = zeros(length(thVec(:,1)),L);
% Create a spline object for faster computations. 
thVecNew = spline(N,thVec);
%
for k=1:length(thVec(:,1))
    sigma(k) = (sigma0^2)*norm(mu_fol(k) - mu_unf(k));
end
%
thVec_new = ppval(thVecNew,NN);
%
for k =1:length(thVec(:,1))
   for m=1:L
       fi(k,m) = F0*exp(-(norm(thVec_new(k,m)-mu_fol(k))/sigma(k)));
   end
end
%
V = zeros(1,L); 
%
% The canoncial WSS summation
for i=1:length(thVec(:,1))
    V = (1/82) * (V + sin(2*pi*fi(i,:).*thVec_new(i,:)));
end
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Step-4: Draw the final results and generate the WSS-based sound. Save the 
% generated data in files defined in Step-0. 
%
fig1 = figure('units','normalized','outerposition',[0 0 1 1]);
plot(linspace(0,duration,length(V)),V,'k','linewidth',0.01)
grid on
xlabel('$$t$$ [s]','interpreter','latex','fontSize',40)
ylabel('$$s(t)$$','interpreter',...
    'latex','fontSize',40)
set(gca,'FontSize',40)
%
% Uncomment  to print  the  figure to a png file. 
% print(fig1,figStr2,'-dpng','-r300')
%
fig2 = figure('units','normalized','outerposition',[0 0 1 1]);
%
subplot(1,2,1)
plot3(thVec(3,:),thVec(29,:),thVec(79,:),'k','LineWidth',2)
hold on
plot3(thVec(3,1),thVec(29,1),thVec(79,1),'d','MarkerSize', 20,...
    'MarkerFaceColor', 'r')
plot3(thVec(3,end),thVec(29,end),thVec(79,end),'d','MarkerSize', 20,...
    'MarkerFaceColor', 'g')
xlabel('$$\theta_4$$ [rad]','interpreter','latex','fontSize',40)
ylabel('$$\theta_{30}$$ [rad]','interpreter',...
    'latex','fontSize',40)
zlabel('$$\theta_{80}$$ [rad]','interpreter','latex','fontSize',40)
set(gca,'FontSize',40)
grid on
%
subplot(1,2,2)
plot3(thVec(5,:),thVec(49,:),thVec(71,:),'k','LineWidth',2)
hold on
plot3(thVec(5,1),thVec(49,1),thVec(71,1),'d','MarkerSize', 20,...
    'MarkerFaceColor', 'r')
plot3(thVec(5,end),thVec(49,end),thVec(71,end),'d','MarkerSize', 20,...
    'MarkerFaceColor', 'g')
xlabel('$$\theta_6$$ [rad]','interpreter','latex','fontSize',40)
ylabel('$$\theta_{50}$$ [rad]','interpreter',...
    'latex','fontSize',40)
zlabel('$$\theta_{72}$$ [rad]','interpreter','latex','fontSize',40)
grid on
set(gca,'FontSize',40)
%
% Uncomment  to print  the  figure to a png file. 
% print(fig2,'canonicalProjectedPath','-dpng','-r300')
% clear  fig1 
%
fig3 = figure('units','normalized','outerposition',[0 0 1 1]);
pspectrum(V,Fs,'spectrogram')
title('')
xlabel('$$t$$ [s]','interpreter','latex','fontSize',40)
ylabel('$$f$$ [kHz]','interpreter',...
    'latex','fontSize',40)
set(gca,'FontSize',40)
%
% Uncomment  to print  the  figure to a png file. 
% print(fig3,figStr3,'-dpng','-r300')
% clear fig2
%
% Uncomment to  save the results in a  .mat file.  
% save(fileStr)
%To Play the output sound uncomment this line
 sound(V,Fs);
%
% Uncomment to  write the generated sound to a .wav file. 
% audiowrite(audioStr,V,Fs)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
