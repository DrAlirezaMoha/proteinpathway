
%PROTO_PATH2SOUND 
%
% Make a given signal periodic --> do an FFT on it --> synthesize and 
% write onto .wav

% Two points of view --> (i) shape-based sound: use the conformation vector
%                       (ii) path-based sound: use the path of a given
%                       dihedral angle 

protVecSize = length(thVec(:,1));
duration = 2; % duration in seconds
freqVecProt  = 65 * (1:protVecSize); % a length n vector of frequencies in Hz
             % where n is the number of dihedral angles of the chain.
             % 55 Hz ---> low low low A
gammaVecProt = pi/180 * (1:protVecSize);%gamma is a length n vector of phase 
%  shifts, as a fraction of the 
%  period of the first harmonic f1.            

ampVecProt = thVec(:,floor(end/2)); 
synthesize_fp('protShapeInit.wav',freqVecProt,duration,ampVecProt,gammaVecProt)   

ampVecProt = thVec(:,1);
synthesize_fp('protShapeEnd.wav',freqVecProt,duration,ampVecProt,gammaVecProt)   


